FlexibleFlix Player 2.4.1 (Windows)
===================================

Placeholder release build for the FlexibleFlix download demo.
Unpack, then run FlexibleFlixPlayer.exe.

Requirements: Windows 10 or 11 (64-bit), 4 GB RAM.
No bundled installers, no toolbars, no background services.
