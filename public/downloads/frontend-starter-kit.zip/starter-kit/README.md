FlexibleFlix Frontend Starter Kit 1.8.0
=======================================

A lean Vite + React + TypeScript starting point.
Includes the FlexibleFlix tokens, base and component stylesheets.

Commands:
  bun install
  bun run dev
