FlexibleFlix Player 2.4.1 (macOS)
=================================

Placeholder release build for the FlexibleFlix download demo.
Drag FlexibleFlixPlayer.app into /Applications.

Requirements: macOS 13 Ventura or newer, Apple silicon or Intel.
Notarised and signed for the demo catalog.
